package padroesestruturais.adapter;

public interface IAvaliacao {
    String getAvaliacao();
    void setAvaliacao(String avaliacao);
}
