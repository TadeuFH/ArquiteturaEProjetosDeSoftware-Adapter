package padroesestruturais.bridge;

public class EnsinoMedio implements Escolaridade {

    public float percentualAumento() {
        return 0.0f;
    }
}
