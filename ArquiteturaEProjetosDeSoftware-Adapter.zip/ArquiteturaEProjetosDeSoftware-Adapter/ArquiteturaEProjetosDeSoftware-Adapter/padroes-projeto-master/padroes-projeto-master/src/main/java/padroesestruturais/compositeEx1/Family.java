package padroesestruturais.compositeEx1;

import java.util.ArrayList;
import java.util.List;

public class Family extends Person {

    public Family(String name) {
        super(name, 0);
    }


}
