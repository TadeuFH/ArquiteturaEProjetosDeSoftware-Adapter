package padroesestruturais.facadeEx1;

public class Eletronico extends Produto {
    public Eletronico(String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public void aplicarDesconto() {
        preco = preco * 0.8;
    }
}