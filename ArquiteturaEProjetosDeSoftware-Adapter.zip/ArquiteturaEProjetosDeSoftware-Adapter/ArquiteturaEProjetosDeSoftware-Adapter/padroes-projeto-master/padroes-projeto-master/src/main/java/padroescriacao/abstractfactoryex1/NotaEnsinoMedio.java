package padroescriacao.abstractfactoryex1;

public class NotaEnsinoMedio implements Nota{

    public String emitir() {
        return "Nota de Ensino Medio";
    }
}
