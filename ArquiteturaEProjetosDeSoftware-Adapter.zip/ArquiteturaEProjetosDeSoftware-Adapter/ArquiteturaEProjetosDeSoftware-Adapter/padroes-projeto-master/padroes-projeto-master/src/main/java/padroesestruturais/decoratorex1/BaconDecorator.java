package padroesestruturais.decoratorex1;

public class BaconDecorator extends HamburgerDecorator {
    public BaconDecorator(Hamburger hamburger) {
        super(hamburger);
    }

    public String getDescription() {
        return hamburger.getDescription() + ", bacon";
    }

    public double getCost() {
        return hamburger.getCost() + 2.0;
    }
}
