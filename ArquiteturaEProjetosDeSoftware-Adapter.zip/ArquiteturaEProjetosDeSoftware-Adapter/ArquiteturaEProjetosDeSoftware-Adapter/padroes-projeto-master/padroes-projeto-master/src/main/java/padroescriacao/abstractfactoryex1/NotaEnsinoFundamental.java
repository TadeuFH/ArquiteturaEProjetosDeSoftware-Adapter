package padroescriacao.abstractfactoryex1;

public class NotaEnsinoFundamental implements Nota{

    public String emitir() {
        return "Nota de Ensino Fundamental";
    }
}
