package padroesestruturais.decoratorex1;

import org.junit.Test;
import static org.junit.Assert.*;

public class HamburgerTest {

    @Test
    public void testHamburger() {
        // Criando um hamburger básico
        Hamburger hamburger = new BasicHamburger();

        // Adicionando decoradores
        hamburger = new EggDecorator(hamburger);
        hamburger = new BaconDecorator(hamburger);
        hamburger = new CheeseDecorator(hamburger);

        // Verificando a descrição
        assertEquals("Pão com carne, ovo, bacon, queijo", hamburger.getDescription());

        // Verificando o custo
        assertEquals(9.5, hamburger.getCost(), 0.001);
    }
}